# AI使用日志 - 实训报告智能批改系统开发

## 记录说明
本文件记录使用Trae AI编程工具开发实训报告智能批改系统的过程，包含问题描述、生成代码、理解与修改过程。

---

### 日志1：文档解析模块开发

**提问内容：**
如何使用Python解析docx和pdf文件，提取文本和图片信息？需要支持中文内容。

**生成代码片段：**
```python
from docx import Document
from PyPDF2 import PdfReader
from PIL import Image
import io

def parse_docx(file_path):
    doc = Document(file_path)
    content = []
    images = []
    for para in doc.paragraphs:
        if para.text.strip():
            content.append(para.text)
    for rel in doc.part.rels.values():
        if "image" in rel.target_ref:
            img_data = rel.target_part.blob
            img = Image.open(io.BytesIO(img_data))
            images.append({'width': img.width, 'height': img.height})
    return {'text': '\n'.join(content), 'images': images}

def parse_pdf(file_path):
    reader = PdfReader(file_path)
    content = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            content.append(text)
    return {'text': '\n'.join(content)}
```

**理解与修改：**
- 代码使用python-docx和PyPDF2库解析文档
- 添加了图片信息提取功能
- 需要处理异常情况，避免解析失败导致程序崩溃
- 将代码整合到document_parser.py中，创建DocumentParser类

---

### 日志2：文本相似度计算

**提问内容：**
如何计算两段中文文本的相似度？需要综合使用多种方法提高准确性。

**生成代码片段：**
```python
from fuzzywuzzy import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class SimilarityCalculator:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    
    def fuzzy_match(self, text1, text2):
        return fuzz.token_set_ratio(text1, text2) / 100.0
    
    def cosine_similarity(self, text1, text2):
        tfidf_matrix = self.vectorizer.fit_transform([text1, text2])
        return cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
    
    def combined_similarity(self, text1, text2):
        fuzzy = self.fuzzy_match(text1, text2)
        cosine = self.cosine_similarity(text1, text2)
        return (fuzzy + cosine) / 2
```

**理解与修改：**
- 使用fuzzywuzzy进行模糊匹配，处理关键词顺序不同的情况
- 使用TF-IDF和余弦相似度进行语义匹配
- 综合两种方法得到更准确的相似度分数
- 添加文本清洗预处理步骤，去除特殊字符

---

### 日志3：多维度评分系统设计

**提问内容：**
如何设计一个多维度的评分系统，包含结构完整性、内容准确性、图片质量等维度，并且权重可配置？

**生成代码片段：**
```python
class ScoringEngine:
    def __init__(self, weights=None):
        self.weights = weights or {
            'structure': 10,
            'accuracy': 30,
            'matching': 25,
            'analysis': 20,
            'images': 10,
            'format': 5
        }
    
    def score_structure(self, student_sections, reference_sections):
        found = sum(1 for sec in student_sections.values() if sec['found'])
        return (found / len(reference_sections)) * self.weights['structure']
    
    def score_images(self, student_images, reference_images):
        if not reference_images:
            return self.weights['images']
        ratio = len(student_images) / len(reference_images)
        return min(ratio, 1.0) * self.weights['images']
```

**理解与修改：**
- 将评分维度和权重分离，便于配置
- 添加了评分详情返回，包含扣分原因
- 增加了图片质量评估（尺寸检测）
- 将代码整合到scoring_engine.py中，完善各维度评分逻辑

---

### 日志4：自动评语生成

**提问内容：**
如何根据评分结果自动生成个性化评语？评语需要具体指出优缺点和改进建议。

**生成代码片段：**
```python
class CommentGenerator:
    def generate_comments(self, score_result, student_content, reference_content):
        comments = []
        
        structure_score = score_result['scores']['structure'][0]
        if structure_score == 10:
            comments.append("报告结构完整，包含所有必要章节。")
        else:
            missing = [name for name, sec in score_result['section_comparison'].items() 
                       if not sec['found_in_student']]
            if missing:
                comments.append(f"缺少章节：{', '.join(missing)}")
        
        total_score = score_result['total_score']
        if total_score >= 90:
            comments.append("总体评价：报告优秀！")
        elif total_score >= 60:
            comments.append("总体评价：报告及格，建议针对上述问题改进。")
        else:
            comments.append("总体评价：需要大幅修改。")
        
        return '\n'.join(comments)
```

**理解与修改：**
- 根据各维度得分生成针对性评语
- 添加差异对比摘要功能
- 确保评语不低于100字
- 分别指出优点和不足，并给出具体改进建议

---

### 日志5：报告输出与批量处理

**提问内容：**
如何生成JSON和HTML格式的批改报告？如何实现批量处理多个学生报告？

**生成代码片段：**
```python
import json
from datetime import datetime

class ReportGenerator:
    def generate_json_report(self, result, filename, output_dir):
        report = {
            'timestamp': datetime.now().isoformat(),
            'filename': filename,
            'total_score': result['total_score'],
            'scores': result['scores'],
            'comments': result['comments']
        }
        output_path = os.path.join(output_dir, f"{filename}_批改结果.json")
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        return output_path
    
    def generate_html_report(self, result, filename, output_dir):
        html = f"""
        <html>
        <body>
        <h1>批改结果：{filename}</h1>
        <div>总分：{result['total_score']}</div>
        </body>
        </html>
        """
        output_path = os.path.join(output_dir, f"{filename}_批改结果.html")
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        return output_path
```

**理解与修改：**
- 添加HTML报告的完整模板，美化样式
- 实现批量处理功能，遍历input目录
- 添加命令行和Web两种界面模式
- 创建app.py实现Streamlit Web界面

---

## 总结

通过与Trae AI编程工具的5次交互，成功完成了实训报告智能批改系统的核心功能开发：

1. **文档解析**：支持docx和pdf格式的文本和图片提取
2. **相似度计算**：综合使用模糊匹配和余弦相似度
3. **评分系统**：多维度评分，权重可配置
4. **评语生成**：根据评分结果自动生成个性化评语
5. **报告输出**：支持JSON和HTML格式，支持批量处理

整个开发过程中，Trae提供了准确的代码建议和实现思路，显著提高了开发效率。
