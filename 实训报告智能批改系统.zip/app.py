import streamlit as st
import os
from config import OUTPUT_DIR
from document_parser import DocumentParser
from scoring_engine import ScoringEngine
from comment_generator import CommentGenerator
from report_generator import ReportGenerator

class StreamlitApp:
    def __init__(self):
        self.parser = DocumentParser()
        self.scoring_engine = ScoringEngine()
        self.comment_generator = CommentGenerator()
        self.report_generator = ReportGenerator()

    def run(self):
        st.set_page_config(page_title="实训报告智能批改系统", layout="wide")
        
        st.title("📝 实训报告智能批改系统")
        st.markdown("基于Trae AI编程工具开发")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📎 上传参考文档")
            reference_file = st.file_uploader("选择满分参考答案报告", type=['docx', 'pdf'], key='reference')
        
        with col2:
            st.subheader("📎 上传学生报告")
            student_files = st.file_uploader("选择待批改的实训报告（可多选）", type=['docx', 'pdf'], key='students', accept_multiple_files=True)
        
        if st.button("🚀 开始批改", disabled=not (reference_file and student_files)):
            with st.spinner('正在批改中...'):
                reference_content = self.parser.parse(reference_file)
                reference_sections = self.parser.detect_sections(reference_content)
                
                results = []
                for student_file in student_files:
                    try:
                        with open(f"temp_{student_file.name}", 'wb') as f:
                            f.write(student_file.getbuffer())
                        
                        student_content = self.parser.parse(f"temp_{student_file.name}")
                        student_sections = self.parser.detect_sections(student_content)
                        
                        score_result = self.scoring_engine.score(
                            student_content, reference_content, student_sections, reference_sections
                        )
                        
                        score_result['comments'] = self.comment_generator.generate_comments(
                            score_result, student_content, reference_content
                        )
                        score_result['difference_summary'] = self.comment_generator.generate_difference_summary(
                            score_result['section_comparison']
                        )
                        
                        json_path = self.report_generator.generate_json_report(
                            score_result, student_file.name, reference_file.name, OUTPUT_DIR
                        )
                        html_path = self.report_generator.generate_html_report(
                            score_result, student_file.name, reference_file.name, OUTPUT_DIR
                        )
                        
                        results.append({
                            'filename': student_file.name,
                            'result': score_result,
                            'json_path': json_path,
                            'html_path': html_path
                        })
                        
                        os.remove(f"temp_{student_file.name}")
                    except Exception as e:
                        st.error(f"批改 {student_file.name} 失败: {str(e)}")
                
                if results:
                    st.success("✅ 批改完成！")
                    
                    for res in results:
                        st.subheader(f"📊 {res['filename']}")
                        
                        col_a, col_b = st.columns([1, 3])
                        with col_a:
                            st.metric("总分", f"{res['result']['total_score']}/100")
                            
                            st.write("**各维度得分：**")
                            scores = res['result']['scores']
                            st.write(f"- 结构完整性: {round(scores['structure'][0], 1)}/10")
                            st.write(f"- 步骤准确性: {round(scores['accuracy'][0], 1)}/30")
                            st.write(f"- 结果匹配度: {round(scores['matching'][0], 1)}/25")
                            st.write(f"- 分析深度: {round(scores['analysis'][0], 1)}/20")
                            st.write(f"- 图片质量: {round(scores['images'][0], 1)}/10")
                            st.write(f"- 格式规范: {round(scores['format'][0], 1)}/5")
                            
                            with open(res['json_path'], 'r', encoding='utf-8') as f:
                                st.download_button(
                                    "📥 下载JSON报告",
                                    f.read(),
                                    file_name=os.path.basename(res['json_path']),
                                    mime='application/json'
                                )
                            
                            with open(res['html_path'], 'r', encoding='utf-8') as f:
                                st.download_button(
                                    "📥 下载HTML报告",
                                    f.read(),
                                    file_name=os.path.basename(res['html_path']),
                                    mime='text/html'
                                )
                        
                        with col_b:
                            st.write("**差异对比：**")
                            st.info(res['result']['difference_summary'])
                            
                            st.write("**详细评语：**")
                            st.write(res['result']['comments'])

if __name__ == '__main__':
    app = StreamlitApp()
    app.run()
