import os
import re
from docx import Document
from PyPDF2 import PdfReader
from PIL import Image
import io

class DocumentParser:
    def __init__(self):
        pass

    def parse_docx(self, file_path):
        doc = Document(file_path)
        content = []
        images = []
        
        for para in doc.paragraphs:
            if para.text.strip():
                content.append(para.text)
        
        for rel in doc.part.rels.values():
            if "image" in rel.target_ref:
                try:
                    img_data = rel.target_part.blob
                    img = Image.open(io.BytesIO(img_data))
                    images.append({
                        'width': img.width,
                        'height': img.height,
                        'format': img.format,
                        'size': len(img_data)
                    })
                except:
                    pass
        
        return {
            'text': '\n'.join(content),
            'paragraphs': content,
            'images': images,
            'image_count': len(images)
        }

    def parse_pdf(self, file_path):
        reader = PdfReader(file_path)
        content = []
        images = []
        
        for page in reader.pages:
            text = page.extract_text()
            if text:
                content.append(text)
            
            for img in page.images:
                try:
                    img_obj = Image.open(io.BytesIO(img.data))
                    images.append({
                        'width': img_obj.width,
                        'height': img_obj.height,
                        'format': img_obj.format,
                        'size': len(img.data)
                    })
                except:
                    pass
        
        return {
            'text': '\n'.join(content),
            'paragraphs': content,
            'images': images,
            'image_count': len(images)
        }

    def parse(self, file_path):
        ext = os.path.splitext(file_path)[1].lower()
        if ext == '.docx':
            return self.parse_docx(file_path)
        elif ext == '.pdf':
            return self.parse_pdf(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    def detect_sections(self, content):
        sections = {}
        text = content['text']
        paragraphs = content['paragraphs']
        
        from config import SECTION_KEYWORDS
        
        for section_name, keywords in SECTION_KEYWORDS.items():
            sections[section_name] = {'found': False, 'content': '', 'start_idx': -1, 'end_idx': -1}
            for i, para in enumerate(paragraphs):
                for keyword in keywords:
                    if keyword in para and len(para) < 50:
                        sections[section_name]['found'] = True
                        sections[section_name]['start_idx'] = i
                        break
        
        for i, section_name in enumerate(SECTION_KEYWORDS.keys()):
            if sections[section_name]['start_idx'] >= 0:
                next_section_idx = len(paragraphs)
                remaining_sections = list(SECTION_KEYWORDS.keys())[i+1:]
                for next_section in remaining_sections:
                    if sections[next_section]['start_idx'] > sections[section_name]['start_idx']:
                        next_section_idx = sections[next_section]['start_idx']
                        break
                sections[section_name]['end_idx'] = next_section_idx
                sections[section_name]['content'] = '\n'.join(
                    paragraphs[sections[section_name]['start_idx']:next_section_idx]
                )
        
        return sections
