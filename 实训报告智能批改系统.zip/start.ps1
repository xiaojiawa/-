Write-Host "==============================" -ForegroundColor Cyan
Write-Host "   实训报告智能批改系统" -ForegroundColor Cyan
Write-Host "==============================" -ForegroundColor Cyan
Write-Host ""

Write-Host "正在启动服务..." -ForegroundColor Green
Write-Host "请稍候，服务启动需要几秒钟时间..." -ForegroundColor Yellow
Write-Host ""

& "C:\Program Files\Python310\python.exe" backend/app.py
