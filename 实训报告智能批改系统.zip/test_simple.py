import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from document_parser import DocumentParser
from scoring_engine import ScoringEngine
from comment_generator import CommentGenerator
from report_generator import ReportGenerator

def create_test_documents():
    try:
        from docx import Document
    except ImportError:
        print("python-docx not installed, creating test text files instead")
        return create_test_text_files()
    
    ref_doc = Document()
    ref_doc.add_heading('RAG问答系统实训报告', 0)
    ref_doc.add_heading('一、实训目的', level=1)
    ref_doc.add_paragraph('1. 了解RAG技术的基本原理和应用场景')
    ref_doc.add_paragraph('2. 掌握基于向量数据库的文档检索方法')
    ref_doc.add_paragraph('3. 学会使用LLM模型进行问答生成')
    ref_doc.add_heading('二、实训步骤', level=1)
    ref_doc.add_paragraph('1. 环境搭建：安装必要的依赖库')
    ref_doc.add_paragraph('2. 数据准备：收集并预处理文档数据')
    ref_doc.add_paragraph('3. 向量数据库构建：使用Chroma存储文档向量')
    ref_doc.add_paragraph('4. 检索模块实现：实现语义相似度匹配')
    ref_doc.add_paragraph('5. 问答生成：结合检索结果生成回答')
    ref_doc.add_heading('三、实验结果', level=1)
    ref_doc.add_paragraph('实验结果表明，RAG系统能够有效检索相关文档并生成准确的回答。')
    ref_doc.add_paragraph('准确率达到90%以上，响应时间在2秒以内。')
    ref_doc.add_heading('四、问题反思', level=1)
    ref_doc.add_paragraph('在实验过程中遇到了向量数据库索引构建较慢的问题，通过优化参数得到解决。')
    ref_doc.add_paragraph('另外，LLM模型的输出质量受提示词影响较大，需要精心设计提示词模板。')
    ref_doc.add_heading('五、心得体会', level=1)
    ref_doc.add_paragraph('通过本次实训，我深入理解了RAG技术的核心原理，掌握了实际项目开发技能。')
    ref_doc.add_paragraph('在未来的学习中，我将继续深入研究LLM与检索技术的结合应用。')
    ref_doc.save('reference/reference_project1.docx')
    print("Created reference docx")
    
    stu_doc = Document()
    stu_doc.add_heading('RAG问答系统实训报告', 0)
    stu_doc.add_heading('一、实训目的', level=1)
    stu_doc.add_paragraph('了解RAG技术')
    stu_doc.add_paragraph('掌握文档检索方法')
    stu_doc.add_heading('二、实训步骤', level=1)
    stu_doc.add_paragraph('安装依赖')
    stu_doc.add_paragraph('准备数据')
    stu_doc.add_paragraph('构建向量数据库')
    stu_doc.add_heading('三、实验结果', level=1)
    stu_doc.add_paragraph('实验结果较好，系统运行正常')
    stu_doc.add_heading('四、心得体会', level=1)
    stu_doc.add_paragraph('通过实训学到了很多知识')
    stu_doc.save('input/student_report1.docx')
    print("Created student docx")
    
    return True

def create_test_text_files():
    ref_content = """RAG问答系统实训报告

一、实训目的
1. 了解RAG技术的基本原理和应用场景
2. 掌握基于向量数据库的文档检索方法
3. 学会使用LLM模型进行问答生成

二、实训步骤
1. 环境搭建：安装必要的依赖库
2. 数据准备：收集并预处理文档数据
3. 向量数据库构建：使用Chroma存储文档向量
4. 检索模块实现：实现语义相似度匹配
5. 问答生成：结合检索结果生成回答

三、实验结果
实验结果表明，RAG系统能够有效检索相关文档并生成准确的回答。
准确率达到90%以上，响应时间在2秒以内。

四、问题反思
在实验过程中遇到了向量数据库索引构建较慢的问题，通过优化参数得到解决。
另外，LLM模型的输出质量受提示词影响较大，需要精心设计提示词模板。

五、心得体会
通过本次实训，我深入理解了RAG技术的核心原理，掌握了实际项目开发技能。
在未来的学习中，我将继续深入研究LLM与检索技术的结合应用。
"""
    
    stu_content = """RAG问答系统实训报告

一、实训目的
了解RAG技术
掌握文档检索方法

二、实训步骤
安装依赖
准备数据
构建向量数据库

三、实验结果
实验结果较好，系统运行正常

四、心得体会
通过实训学到了很多知识
"""
    
    with open('reference/reference_project1.txt', 'w', encoding='utf-8') as f:
        f.write(ref_content)
    
    with open('input/student_report1.txt', 'w', encoding='utf-8') as f:
        f.write(stu_content)
    
    return False

def test_system():
    print("=" * 60)
    print("      实训报告智能批改系统 - 测试")
    print("=" * 60)
    
    print("\n1. 创建测试文档...")
    is_docx = create_test_documents()
    print(f"   ✓ 测试文档创建成功 (格式: {'docx' if is_docx else 'txt'})")
    
    print("\n2. 初始化系统模块...")
    parser = DocumentParser()
    scoring_engine = ScoringEngine()
    comment_generator = CommentGenerator()
    report_generator = ReportGenerator()
    print("   ✓ 模块初始化完成")
    
    print("\n3. 加载参考文档...")
    try:
        if is_docx:
            ref_path = 'reference/reference_project1.docx'
            ref_content = parser.parse(ref_path)
        else:
            ref_path = 'reference/reference_project1.txt'
            with open(ref_path, 'r', encoding='utf-8') as f:
                text = f.read()
            ref_content = {'text': text, 'paragraphs': text.split('\n'), 'images': [], 'image_count': 0}
        
        ref_sections = parser.detect_sections(ref_content)
        print("   ✓ 参考文档加载完成")
        print(f"   - 章节数量: {len([s for s in ref_sections.values() if s['found']])}")
        print(f"   - 图片数量: {len(ref_content['images'])}")
        
    except Exception as e:
        print(f"   ✗ 参考文档加载失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n4. 加载学生报告...")
    try:
        if is_docx:
            stu_path = 'input/student_report1.docx'
            stu_content = parser.parse(stu_path)
        else:
            stu_path = 'input/student_report1.txt'
            with open(stu_path, 'r', encoding='utf-8') as f:
                text = f.read()
            stu_content = {'text': text, 'paragraphs': text.split('\n'), 'images': [], 'image_count': 0}
        
        stu_sections = parser.detect_sections(stu_content)
        print("   ✓ 学生报告加载完成")
        print(f"   - 章节数量: {len([s for s in stu_sections.values() if s['found']])}")
        print(f"   - 图片数量: {len(stu_content['images'])}")
        
    except Exception as e:
        print(f"   ✗ 学生报告加载失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n5. 执行评分...")
    try:
        result = scoring_engine.score(stu_content, ref_content, stu_sections, ref_sections)
        print("   ✓ 评分完成")
        print(f"   - 总分: {result['total_score']}/100")
        
        print("\n   各维度得分:")
        labels = {'structure': '结构完整性', 'accuracy': '步骤准确性', 'matching': '结果匹配度', 
                  'analysis': '分析深度', 'images': '图片质量', 'format': '格式规范'}
        for key, (score, details) in result['scores'].items():
            print(f"     - {labels.get(key, key)}: {round(score, 1)}")
        
    except Exception as e:
        print(f"   ✗ 评分失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n6. 生成评语...")
    try:
        result['comments'] = comment_generator.generate_comments(result, stu_content, ref_content)
        result['difference_summary'] = comment_generator.generate_difference_summary(result['section_comparison'])
        print("   ✓ 评语生成完成")
        print("\n   差异对比摘要:")
        print("   ------------------")
        print(result['difference_summary'])
        print("\n   详细评语:")
        print("   ------------------")
        print(result['comments'])
        
    except Exception as e:
        print(f"   ✗ 评语生成失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n7. 生成批改报告...")
    try:
        json_path = report_generator.generate_json_report(result, 'student_report1.docx', 'reference_project1.docx', 'output')
        html_path = report_generator.generate_html_report(result, 'student_report1.docx', 'reference_project1.docx', 'output')
        print("   ✓ 报告生成完成")
        print(f"   - JSON报告: {json_path}")
        print(f"   - HTML报告: {html_path}")
        
    except Exception as e:
        print(f"   ✗ 报告生成失败: {e}")
        import traceback
        traceback.print_exc()
        return
    
    print("\n" + "=" * 60)
    print("         测试完成！")
    print("=" * 60)

if __name__ == '__main__':
    test_system()
