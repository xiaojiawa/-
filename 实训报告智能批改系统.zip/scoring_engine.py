from config import SCORING_WEIGHTS, IMAGE_THRESHOLD, SIMILARITY_THRESHOLD
from similarity import SimilarityCalculator

class ScoringEngine:
    def __init__(self):
        self.similarity_calc = SimilarityCalculator()

    def score_structure(self, student_sections, reference_sections):
        total_sections = len(reference_sections)
        found_sections = sum(1 for sec in student_sections.values() if sec['found'])
        score = (found_sections / total_sections) * SCORING_WEIGHTS['structure']
        details = {
            'total_sections': total_sections,
            'found_sections': found_sections,
            'missing_sections': [name for name, sec in student_sections.items() if not sec['found']]
        }
        return score, details

    def score_accuracy(self, section_comparison):
        scores = []
        details = []
        for section_name, comp in section_comparison.items():
            if comp['found_in_reference'] and comp['found_in_student']:
                scores.append(comp['similarity'])
                details.append({
                    'section': section_name,
                    'similarity': comp['similarity'],
                    'status': 'matched' if comp['similarity'] >= SIMILARITY_THRESHOLD else 'partial'
                })
            elif comp['found_in_reference'] and not comp['found_in_student']:
                scores.append(0)
                details.append({
                    'section': section_name,
                    'similarity': 0,
                    'status': 'missing'
                })
        
        if not scores:
            return 0, details
        
        avg_similarity = sum(scores) / len(scores)
        score = avg_similarity * SCORING_WEIGHTS['accuracy']
        return score, details

    def score_matching(self, student_content, reference_content):
        similarity = self.similarity_calc.combined_similarity(student_content, reference_content)
        score = similarity * SCORING_WEIGHTS['matching']
        details = {
            'overall_similarity': similarity,
            'threshold': SIMILARITY_THRESHOLD
        }
        return score, details

    def score_analysis(self, student_sections):
        analysis_sections = ['问题反思', '心得体会']
        scores = []
        details = []
        
        for section in analysis_sections:
            if section in student_sections and student_sections[section]['found']:
                content_length = len(student_sections[section]['content'])
                if content_length > 100:
                    scores.append(1.0)
                    details.append({'section': section, 'status': 'complete', 'length': content_length})
                elif content_length > 50:
                    scores.append(0.7)
                    details.append({'section': section, 'status': 'partial', 'length': content_length})
                else:
                    scores.append(0.3)
                    details.append({'section': section, 'status': 'brief', 'length': content_length})
            else:
                scores.append(0)
                details.append({'section': section, 'status': 'missing', 'length': 0})
        
        if not scores:
            return 0, details
        
        avg_score = sum(scores) / len(scores)
        score = avg_score * SCORING_WEIGHTS['analysis']
        return score, details

    def score_images(self, student_images, reference_images):
        if not reference_images:
            return SCORING_WEIGHTS['images'], {'note': '参考文档无图片'}
        
        student_count = len(student_images)
        reference_count = len(reference_images)
        
        if student_count == 0:
            return 0, {'reason': '未包含任何图片'}
        
        ratio = student_count / reference_count
        if ratio >= IMAGE_THRESHOLD:
            base_score = 1.0
        elif ratio >= 0.5:
            base_score = 0.7
        else:
            base_score = 0.3
        
        quality_score = 0.0
        valid_images = 0
        for img in student_images:
            if img['width'] >= 200 and img['height'] >= 200:
                valid_images += 1
        
        if student_count > 0:
            quality_score = valid_images / student_count
        
        overall_score = (base_score + quality_score) / 2
        score = overall_score * SCORING_WEIGHTS['images']
        
        details = {
            'student_image_count': student_count,
            'reference_image_count': reference_count,
            'ratio': ratio,
            'valid_images': valid_images,
            'quality_score': quality_score
        }
        return score, details

    def score_format(self, student_content):
        paragraphs = student_content.get('paragraphs', [])
        if len(paragraphs) < 3:
            return 0, {'reason': '段落过少'}
        
        has_headings = any(len(p) < 30 and any(char in p for char in ['一', '二', '三', '1.', '2.', '3.', '（', '(']) for p in paragraphs)
        if has_headings:
            return SCORING_WEIGHTS['format'], {'status': '格式规范'}
        else:
            return SCORING_WEIGHTS['format'] * 0.5, {'status': '缺少明显标题结构'}

    def calculate_total_score(self, scores):
        return sum(score for score, _ in scores.values())

    def score(self, student_content, reference_content, student_sections, reference_sections):
        section_comparison = self.similarity_calc.compare_sections(student_sections, reference_sections)
        
        scores = {}
        scores['structure'] = self.score_structure(student_sections, reference_sections)
        scores['accuracy'] = self.score_accuracy(section_comparison)
        scores['matching'] = self.score_matching(student_content['text'], reference_content['text'])
        scores['analysis'] = self.score_analysis(student_sections)
        scores['images'] = self.score_images(student_content['images'], reference_content['images'])
        scores['format'] = self.score_format(student_content)
        
        total_score = self.calculate_total_score(scores)
        
        return {
            'scores': scores,
            'total_score': round(total_score, 2),
            'section_comparison': section_comparison
        }
