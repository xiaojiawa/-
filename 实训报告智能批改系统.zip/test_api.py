import requests
import os

def test_single_grade():
    url = 'http://127.0.0.1:5000/api/grade'
    
    ref_path = 'reference/reference_project1.docx'
    stu_path = 'input/student_report1.docx'
    
    if not os.path.exists(ref_path):
        print(f"参考文件不存在: {ref_path}")
        return
    
    if not os.path.exists(stu_path):
        print(f"学生文件不存在: {stu_path}")
        return
    
    try:
        with open(ref_path, 'rb') as ref_file, open(stu_path, 'rb') as stu_file:
            files = {
                'reference': ref_file,
                'student': stu_file
            }
            
            print("正在发送批改请求...")
            response = requests.post(url, files=files)
            
            if response.status_code == 200:
                result = response.json()
                print("\n✅ 批改成功！")
                print(f"总分: {result['total_score']}/100")
                print("\n各维度得分:")
                for key, value in result['scores'].items():
                    labels = {'structure': '结构完整性', 'accuracy': '步骤准确性', 'matching': '结果匹配度', 
                              'analysis': '分析深度', 'images': '图片质量', 'format': '格式规范'}
                    print(f"  - {labels.get(key, key)}: {value}")
                print("\n差异对比摘要:")
                print(result['difference_summary'])
                print("\n详细评语:")
                print(result['comments'])
            else:
                print(f"❌ 请求失败: {response.status_code}")
                print(response.text)
                
    except Exception as e:
        print(f"❌ 发生错误: {e}")

if __name__ == '__main__':
    test_single_grade()
