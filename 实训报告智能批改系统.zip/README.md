# 实训报告智能批改系统

基于Trae AI编程工具开发的实训报告智能批改系统，支持docx和pdf格式文档的自动批改。

## 功能特性

- 📄 **文档解析**: 支持.docx和.pdf格式的实训报告读取
- 🖼️ **图片处理**: 统计图片数量、检测图片尺寸
- 🔍 **章节识别**: 自动识别实训报告常见结构
- 📊 **智能评分**: 多维度自动评分（结构完整性、准确性、匹配度等）
- 📝 **评语生成**: 自动生成个性化评语和改进建议
- 📑 **报告输出**: 支持JSON和HTML格式的批改报告
- 🚀 **批量处理**: 支持批量批改多个学生报告

## 技术架构

```
├── config.py          # 配置文件（评分权重、阈值等）
├── document_parser.py # 文档解析模块
├── similarity.py      # 相似度计算模块
├── scoring_engine.py  # 评分引擎
├── comment_generator.py # 评语生成模块
├── report_generator.py  # 报告生成模块
├── main.py            # 命令行界面
└── app.py             # Streamlit Web界面
```

## 环境要求

- Python 3.8+
- 依赖库：见requirements.txt

## 安装步骤

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 创建目录结构（系统自动创建）：
- input/: 存放待批改的学生报告
- reference/: 存放参考答案报告
- output/: 存放批改结果

## 使用方法

### 方法一：命令行模式

1. 将参考答案放入 `reference/` 目录
2. 将学生报告放入 `input/` 目录
3. 运行：
```bash
python main.py
```

### 方法二：Web界面模式

```bash
streamlit run app.py
```

然后在浏览器中访问显示的URL。

## 评分维度

| 维度 | 分值 | 说明 |
|------|------|------|
| 结构完整性 | 10分 | 章节完整性评估 |
| 步骤/代码准确性 | 30分 | 内容与参考答案的匹配度 |
| 结果匹配度 | 25分 | 整体内容相似度 |
| 问题分析深度 | 20分 | 反思与心得体会质量 |
| 图片/图表质量 | 10分 | 图片数量与质量 |
| 格式规范 | 5分 | 文档格式规范性 |

## 配置说明

在 `config.py` 中可配置：

```python
SCORING_WEIGHTS = {
    'structure': 10,    # 结构完整性权重
    'accuracy': 30,     # 准确性权重
    'matching': 25,     # 匹配度权重
    'analysis': 20,     # 分析深度权重
    'images': 10,       # 图片质量权重
    'format': 5         # 格式权重
}

IMAGE_THRESHOLD = 0.8    # 图片数量阈值
SIMILARITY_THRESHOLD = 0.6  # 相似度阈值
```

## 输出格式

### JSON报告
包含详细的评分数据和评语。

### HTML报告
可视化的批改结果，便于查看和分享。

## 项目结构

```
.
├── input/              # 学生报告目录
├── output/             # 批改结果目录
├── reference/          # 参考文档目录
├── config.py           # 配置文件
├── document_parser.py  # 文档解析
├── similarity.py       # 相似度计算
├── scoring_engine.py   # 评分引擎
├── comment_generator.py # 评语生成
├── report_generator.py  # 报告生成
├── main.py             # 命令行入口
├── app.py              # Web入口
├── requirements.txt    # 依赖列表
└── README.md           # 使用说明
```

## 离线运行

本系统支持离线运行，无需网络连接。

## 注意事项

1. 确保参考文档和学生报告格式正确
2. PDF文件需要包含可提取的文本内容
3. 大文件处理可能需要较长时间

## 开发说明

本系统基于Trae AI编程工具开发，使用了以下技术：
- python-docx: docx文档解析
- PyPDF2: PDF文档解析
- scikit-learn: 文本相似度计算
- fuzzywuzzy: 模糊匹配
- streamlit: Web界面框架
