# GitHub 上传指南

## 方法一：手动上传（推荐）

1. **打开浏览器**，访问 `https://github.com/xiaojiawa/-`

2. **点击 "Add file"** → "Upload files"

3. **拖拽整个项目文件夹** 到浏览器窗口

4. **填写提交信息**：
   - Commit message: `Initial commit - 实训报告智能批改系统`
   - 点击 "Commit changes"

## 方法二：使用 Git 命令

### 步骤1：安装 Git
1. 下载 Git：https://git-scm.com/download/win
2. 安装时选择默认选项即可

### 步骤2：配置 Git
```bash
git config --global user.name "你的GitHub用户名"
git config --global user.email "你的GitHub邮箱"
```

### 步骤3：上传代码
```bash
# 进入项目目录
cd C:\Users\Administrator\Desktop\awa\1

# 初始化仓库
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit - 实训报告智能批改系统"

# 添加远程仓库
git remote add origin https://github.com/xiaojiawa/-.git

# 推送到远程
git push -u origin main
```

## 方法三：使用 GitHub Desktop

1. 下载 GitHub Desktop：https://desktop.github.com/
2. 安装并登录你的 GitHub 账号
3. 点击 "File" → "Add local repository"
4. 选择项目文件夹
5. 点击 "Publish repository"
6. 选择已有的仓库 `xiaojiawa/-`

## 项目文件清单

```
.
├── backend/
│   └── app.py              # Flask后端API
├── frontend/
│   └── index.html          # 前端界面
├── document_parser.py       # 文档解析模块
├── scoring_engine.py        # 评分引擎
├── similarity.py            # 相似度计算
├── comment_generator.py     # 评语生成
├── report_generator.py      # 报告生成
├── config.py               # 配置文件
├── requirements.txt        # 依赖列表
├── README.md              # 项目说明
├── AI_LOG.md              # AI使用日志
├── OPERATION_GUIDE.md      # 操作教程
├── start.ps1              # 启动脚本
├── start.bat              # 备用启动脚本
├── 打开系统.url           # 快捷方式
├── 打开系统.html          # 跳转页面
├── input/                 # 学生报告目录
├── reference/             # 参考文档目录
└── output/                # 批改结果目录
```
