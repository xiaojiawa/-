@echo off
echo ==============================
echo   实训报告智能批改系统
echo ==============================
echo.

echo 正在启动服务...
echo 请稍候，服务启动需要几秒钟时间...
echo.

python backend/app.py

pause
