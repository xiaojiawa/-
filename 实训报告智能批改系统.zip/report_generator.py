import json
import os
from datetime import datetime

class ReportGenerator:
    def __init__(self):
        pass

    def generate_json_report(self, result, original_filename, reference_filename, output_dir):
        report = {
            'timestamp': datetime.now().isoformat(),
            'original_filename': original_filename,
            'reference_filename': reference_filename,
            'total_score': result['total_score'],
            'scores': {},
            'comments': result.get('comments', ''),
            'difference_summary': result.get('difference_summary', ''),
            'section_comparison': result.get('section_comparison', {})
        }

        for key, (score, details) in result['scores'].items():
            report['scores'][key] = {
                'score': round(score, 2),
                'details': details
            }

        output_filename = f"{os.path.splitext(original_filename)[0]}_批改结果.json"
        output_path = os.path.join(output_dir, output_filename)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)

        return output_path

    def generate_html_report(self, result, original_filename, reference_filename, output_dir):
        diff_summary = result.get('difference_summary', '无差异').replace('\n', '<br>')
        comments = result.get('comments', '无评语').replace('\n', '<br>')
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        html_template = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>实训报告批改结果 - {original_filename}</title>
    <style>
        body {{ font-family: 'Microsoft YaHei', sans-serif; margin: 40px; background-color: #f5f5f5; }}
        .container {{ max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
        h2 {{ color: #3498db; margin-top: 30px; }}
        .score-box {{ display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px 40px; border-radius: 12px; font-size: 24px; font-weight: bold; margin: 20px 0; }}
        .score-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 20px 0; }}
        .score-item {{ background: #ecf0f1; padding: 15px; border-radius: 8px; text-align: center; }}
        .score-label {{ color: #7f8c8d; font-size: 14px; }}
        .score-value {{ font-size: 20px; font-weight: bold; color: #2c3e50; }}
        .comments {{ background: #e8f4f8; padding: 20px; border-radius: 8px; line-height: 1.8; }}
        .diff-summary {{ background: #fff3cd; padding: 20px; border-radius: 8px; margin-top: 20px; }}
        .section-table {{ width: 100%; border-collapse: collapse; margin-top: 20px; }}
        .section-table th, .section-table td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
        .section-table th {{ background: #3498db; color: white; }}
        .status-matched {{ color: #27ae60; }}
        .status-partial {{ color: #f39c12; }}
        .status-missing {{ color: #e74c3c; }}
        .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; color: #7f8c8d; font-size: 14px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>实训报告智能批改结果</h1>
        <p><strong>原始文件：</strong>{original_filename}</p>
        <p><strong>参考文件：</strong>{reference_filename}</p>
        <p><strong>批改时间：</strong>{timestamp}</p>
        
        <div class="score-box">总分：{total_score} / 100</div>
        
        <h2>各维度得分详情</h2>
        <div class="score-grid">
            <div class="score-item"><div class="score-label">结构完整性</div><div class="score-value">{structure_score} / 10</div></div>
            <div class="score-item"><div class="score-label">步骤/代码准确性</div><div class="score-value">{accuracy_score} / 30</div></div>
            <div class="score-item"><div class="score-label">结果匹配度</div><div class="score-value">{matching_score} / 25</div></div>
            <div class="score-item"><div class="score-label">问题分析深度</div><div class="score-value">{analysis_score} / 20</div></div>
            <div class="score-item"><div class="score-label">图片/图表质量</div><div class="score-value">{images_score} / 10</div></div>
            <div class="score-item"><div class="score-label">格式规范</div><div class="score-value">{format_score} / 5</div></div>
        </div>
        
        <h2>差异对比摘要</h2>
        <div class="diff-summary">
            {diff_summary}
        </div>
        
        <h2>详细评语</h2>
        <div class="comments">
            {comments}
        </div>
        
        <h2>章节比对详情</h2>
        <table class="section-table">
            <tr><th>章节名称</th><th>学生报告</th><th>参考答案</th><th>相似度</th></tr>
            {section_rows}
        </table>
        
        <div class="footer">
            实训报告智能批改系统 | 基于Trae AI编程工具开发
        </div>
    </div>
</body>
</html>
        """.format(
            original_filename=original_filename,
            reference_filename=reference_filename,
            timestamp=timestamp,
            total_score=result['total_score'],
            structure_score=round(result['scores']['structure'][0], 1),
            accuracy_score=round(result['scores']['accuracy'][0], 1),
            matching_score=round(result['scores']['matching'][0], 1),
            analysis_score=round(result['scores']['analysis'][0], 1),
            images_score=round(result['scores']['images'][0], 1),
            format_score=round(result['scores']['format'][0], 1),
            diff_summary=diff_summary,
            comments=comments,
            section_rows=self._generate_section_rows(result.get('section_comparison', {}))
        )
        
        output_filename = f"{os.path.splitext(original_filename)[0]}_批改结果.html"
        output_path = os.path.join(output_dir, output_filename)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_template)

        return output_path

    def _generate_section_rows(self, section_comparison):
        rows = []
        for section_name, comp in section_comparison.items():
            student_status = '存在' if comp['found_in_student'] else '缺失'
            ref_status = '存在' if comp['found_in_reference'] else '缺失'
            similarity = f"{round(comp['similarity'] * 100)}%"
            rows.append(f"<tr><td>{section_name}</td><td>{student_status}</td><td>{ref_status}</td><td>{similarity}</td></tr>")
        return '\n'.join(rows)
