import os
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from document_parser import DocumentParser
from scoring_engine import ScoringEngine
from comment_generator import CommentGenerator
from report_generator import ReportGenerator
import tempfile

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/api/grade', methods=['POST'])
def grade_report():
    try:
        if 'reference' not in request.files or 'student' not in request.files:
            return jsonify({'error': '请上传参考文档和学生报告'}), 400
        
        reference_file = request.files['reference']
        student_file = request.files['student']
        
        ref_path = os.path.join(UPLOAD_FOLDER, 'reference_' + reference_file.filename)
        stu_path = os.path.join(UPLOAD_FOLDER, 'student_' + student_file.filename)
        
        reference_file.save(ref_path)
        student_file.save(stu_path)
        
        parser = DocumentParser()
        scoring_engine = ScoringEngine()
        comment_generator = CommentGenerator()
        
        ref_content = parser.parse(ref_path)
        ref_sections = parser.detect_sections(ref_content)
        
        stu_content = parser.parse(stu_path)
        stu_sections = parser.detect_sections(stu_content)
        
        result = scoring_engine.score(stu_content, ref_content, stu_sections, ref_sections)
        result['comments'] = comment_generator.generate_comments(result, stu_content, ref_content)
        result['difference_summary'] = comment_generator.generate_difference_summary(result['section_comparison'])
        
        os.remove(ref_path)
        os.remove(stu_path)
        
        return jsonify({
            'success': True,
            'total_score': result['total_score'],
            'scores': {
                'structure': round(result['scores']['structure'][0], 1),
                'accuracy': round(result['scores']['accuracy'][0], 1),
                'matching': round(result['scores']['matching'][0], 1),
                'analysis': round(result['scores']['analysis'][0], 1),
                'images': round(result['scores']['images'][0], 1),
                'format': round(result['scores']['format'][0], 1)
            },
            'comments': result['comments'],
            'difference_summary': result['difference_summary'],
            'section_comparison': result['section_comparison']
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/batch_grade', methods=['POST'])
def batch_grade():
    try:
        if 'reference' not in request.files:
            return jsonify({'error': '请上传参考文档'}), 400
        
        reference_file = request.files['reference']
        student_files = request.files.getlist('students')
        
        if not student_files:
            return jsonify({'error': '请上传至少一份学生报告'}), 400
        
        ref_path = os.path.join(UPLOAD_FOLDER, 'reference_' + reference_file.filename)
        reference_file.save(ref_path)
        
        parser = DocumentParser()
        scoring_engine = ScoringEngine()
        comment_generator = CommentGenerator()
        report_generator = ReportGenerator()
        
        ref_content = parser.parse(ref_path)
        ref_sections = parser.detect_sections(ref_content)
        
        results = []
        for student_file in student_files:
            stu_path = os.path.join(UPLOAD_FOLDER, 'student_' + student_file.filename)
            student_file.save(stu_path)
            
            try:
                stu_content = parser.parse(stu_path)
                stu_sections = parser.detect_sections(stu_content)
                
                result = scoring_engine.score(stu_content, ref_content, stu_sections, ref_sections)
                result['comments'] = comment_generator.generate_comments(result, stu_content, ref_content)
                result['difference_summary'] = comment_generator.generate_difference_summary(result['section_comparison'])
                
                results.append({
                    'filename': student_file.filename,
                    'total_score': result['total_score'],
                    'scores': {
                        'structure': round(result['scores']['structure'][0], 1),
                        'accuracy': round(result['scores']['accuracy'][0], 1),
                        'matching': round(result['scores']['matching'][0], 1),
                        'analysis': round(result['scores']['analysis'][0], 1),
                        'images': round(result['scores']['images'][0], 1),
                        'format': round(result['scores']['format'][0], 1)
                    },
                    'comments': result['comments'],
                    'difference_summary': result['difference_summary']
                })
            except Exception as e:
                results.append({
                    'filename': student_file.filename,
                    'error': str(e)
                })
            
            os.remove(stu_path)
        
        os.remove(ref_path)
        
        return jsonify({
            'success': True,
            'results': results
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'frontend')

@app.route('/')
def index():
    return send_from_directory(FRONTEND_DIR, 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory(FRONTEND_DIR, path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
