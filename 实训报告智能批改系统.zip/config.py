import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(BASE_DIR, 'input')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output')
REFERENCE_DIR = os.path.join(BASE_DIR, 'reference')

os.makedirs(INPUT_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(REFERENCE_DIR, exist_ok=True)

SCORING_WEIGHTS = {
    'structure': 10,
    'accuracy': 30,
    'matching': 25,
    'analysis': 20,
    'images': 10,
    'format': 5
}

IMAGE_THRESHOLD = 0.8
SIMILARITY_THRESHOLD = 0.6

SECTION_KEYWORDS = {
    '实训目的': ['实训目的', '实验目的', '目的', '实验目标', '实训目标'],
    '实训步骤': ['实训步骤', '实验步骤', '步骤', '流程', '操作步骤'],
    '实验结果': ['实验结果', '实训结果', '结果', '实验数据', '结果分析'],
    '问题反思': ['问题反思', '反思', '问题分析', '遇到的问题', '难点'],
    '心得体会': ['心得体会', '总结', '体会', '收获', '感想']
}
