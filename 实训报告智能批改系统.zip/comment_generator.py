class CommentGenerator:
    def __init__(self):
        pass

    def generate_comments(self, score_result, student_content, reference_content):
        comments = []
        scores = score_result['scores']
        section_comparison = score_result['section_comparison']

        structure_score, structure_details = scores['structure']
        if structure_score == 10:
            comments.append("报告结构完整，包含了所有必要的章节。")
        else:
            missing = structure_details.get('missing_sections', [])
            if missing:
                comments.append(f"报告缺少以下章节：{', '.join(missing)}。建议补充这些部分以完善报告结构。")
            else:
                comments.append("报告结构基本完整，但某些章节可能不够清晰。")

        accuracy_score, accuracy_details = scores['accuracy']
        matched_sections = [d['section'] for d in accuracy_details if d['status'] == 'matched']
        partial_sections = [d['section'] for d in accuracy_details if d['status'] == 'partial']
        missing_sections = [d['section'] for d in accuracy_details if d['status'] == 'missing']
        
        if matched_sections:
            comments.append(f"以下章节内容与参考答案匹配度较高：{', '.join(matched_sections)}。")
        if partial_sections:
            comments.append(f"以下章节内容需要进一步完善：{', '.join(partial_sections)}。建议参考参考答案补充相关内容。")
        if missing_sections:
            comments.append(f"以下章节内容缺失：{', '.join(missing_sections)}。请对照参考答案补充完整。")

        matching_score, matching_details = scores['matching']
        similarity = matching_details.get('overall_similarity', 0)
        if similarity >= 0.8:
            comments.append("报告整体内容与参考答案高度匹配，知识点覆盖全面。")
        elif similarity >= 0.6:
            comments.append("报告内容与参考答案有一定匹配度，但仍有提升空间。建议重点关注差异部分。")
        else:
            comments.append("报告内容与参考答案差异较大，建议重新梳理知识点，对照参考答案进行补充和修正。")

        analysis_score, analysis_details = scores['analysis']
        analysis_sections = []
        for detail in analysis_details:
            if detail['status'] == 'complete':
                analysis_sections.append(f"{detail['section']}（内容详实）")
            elif detail['status'] == 'partial':
                analysis_sections.append(f"{detail['section']}（内容较简略）")
            else:
                analysis_sections.append(f"{detail['section']}（缺失）")
        
        comments.append(f"问题反思与心得体会部分：{'; '.join(analysis_sections)}。建议深入分析实验过程中遇到的问题及其解决方案。")

        images_score, images_details = scores['images']
        student_count = images_details.get('student_image_count', 0)
        reference_count = images_details.get('reference_image_count', 0)
        if student_count == 0:
            comments.append("报告中未包含任何图片。建议添加流程图、实验结果截图等可视化内容以增强报告质量。")
        elif student_count < reference_count:
            comments.append(f"报告包含{student_count}张图片，参考答案包含{reference_count}张图片。建议补充必要的图片以完整展示实验过程和结果。")
        else:
            comments.append(f"报告包含{student_count}张图片，数量充足。请确保每张图片都有清晰的图注说明。")

        format_score, format_details = scores['format']
        if format_details.get('status') == '格式规范':
            comments.append("报告格式规范，结构清晰，易于阅读。")
        else:
            comments.append("建议优化报告格式，添加明确的章节标题以提升可读性。")

        total_score = score_result['total_score']
        if total_score >= 90:
            comments.append("总体评价：报告优秀，内容完整、准确，达到了实训要求。")
        elif total_score >= 80:
            comments.append("总体评价：报告良好，大部分内容符合要求，建议针对上述问题进行改进。")
        elif total_score >= 60:
            comments.append("总体评价：报告及格，但存在较多需要改进的地方。建议认真对照参考答案进行修改完善。")
        else:
            comments.append("总体评价：报告未达到要求，需要大幅修改。建议重新撰写，重点关注缺失的核心内容。")

        return '\n'.join(comments)

    def generate_difference_summary(self, section_comparison):
        summary = []
        for section_name, comp in section_comparison.items():
            if comp['found_in_reference'] and not comp['found_in_student']:
                summary.append(f"- 缺失章节：{section_name}")
            elif comp['found_in_reference'] and comp['found_in_student']:
                similarity = comp['similarity']
                if similarity < 0.5:
                    summary.append(f"- {section_name}：内容差异较大，建议参考参考答案")
                elif similarity < 0.8:
                    summary.append(f"- {section_name}：内容基本匹配，部分细节需要补充")
        return '\n'.join(summary) if summary else "报告内容与参考答案基本一致"
