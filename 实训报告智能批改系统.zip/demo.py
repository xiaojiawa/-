import requests
import json

def main():
    print('=' * 60)
    print('        📝 实训报告智能批改系统 - 功能演示')
    print('=' * 60)
    print()
    
    url = 'http://127.0.0.1:5000/api/grade'
    
    print('📤 正在上传文件...')
    print('   - 参考文档: reference/reference_project1.docx')
    print('   - 学生报告: input/student_report1.docx')
    print()
    
    with open('reference/reference_project1.docx', 'rb') as ref_file, open('input/student_report1.docx', 'rb') as stu_file:
        files = {
            'reference': ref_file,
            'student': stu_file
        }
        
        print('⏳ 正在批改中，请稍候...')
        response = requests.post(url, files=files)
        result = response.json()
    
    print()
    print('=' * 60)
    print('🏆 批改结果')
    print('=' * 60)
    print(f'总分: {result["total_score"]}/100')
    print()
    
    print('📊 各维度得分详情:')
    labels = {
        'structure': '结构完整性',
        'accuracy': '步骤准确性',
        'matching': '结果匹配度',
        'analysis': '分析深度',
        'images': '图片质量',
        'format': '格式规范'
    }
    
    max_label_length = max(len(label) for label in labels.values())
    for key, value in result['scores'].items():
        label = labels.get(key, key)
        print(f'  {label.ljust(max_label_length)}: {value}')
    print()
    
    print('📋 差异对比摘要:')
    print('-' * 40)
    for line in result['difference_summary'].split('\n'):
        if line.strip():
            print(f'  • {line}')
    print('-' * 40)
    print()
    
    print('💬 详细评语:')
    print('-' * 40)
    print(result['comments'])
    print('-' * 40)
    print()
    
    print('📁 已生成报告:')
    print('   - output/student_report1_批改结果.json')
    print('   - output/student_report1_批改结果.html')
    print()
    print('=' * 60)
    print('✅ 演示完成！')
    print('=' * 60)

if __name__ == '__main__':
    main()
