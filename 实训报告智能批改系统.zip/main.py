import os
import sys
from config import INPUT_DIR, OUTPUT_DIR, REFERENCE_DIR
from document_parser import DocumentParser
from scoring_engine import ScoringEngine
from comment_generator import CommentGenerator
from report_generator import ReportGenerator

class ReportGradingSystem:
    def __init__(self):
        self.parser = DocumentParser()
        self.scoring_engine = ScoringEngine()
        self.comment_generator = CommentGenerator()
        self.report_generator = ReportGenerator()

    def load_reference(self, reference_path):
        if not os.path.exists(reference_path):
            raise FileNotFoundError(f"参考文件不存在: {reference_path}")
        content = self.parser.parse(reference_path)
        sections = self.parser.detect_sections(content)
        return content, sections

    def grade_report(self, student_path, reference_content, reference_sections):
        if not os.path.exists(student_path):
            raise FileNotFoundError(f"学生报告不存在: {student_path}")
        
        student_content = self.parser.parse(student_path)
        student_sections = self.parser.detect_sections(student_content)
        
        score_result = self.scoring_engine.score(
            student_content, 
            reference_content, 
            student_sections, 
            reference_sections
        )
        
        score_result['comments'] = self.comment_generator.generate_comments(
            score_result, student_content, reference_content
        )
        score_result['difference_summary'] = self.comment_generator.generate_difference_summary(
            score_result['section_comparison']
        )
        
        return score_result

    def batch_grade(self, reference_path):
        reference_content, reference_sections = self.load_reference(reference_path)
        reference_filename = os.path.basename(reference_path)
        
        results = []
        for filename in os.listdir(INPUT_DIR):
            ext = os.path.splitext(filename)[1].lower()
            if ext in ('.docx', '.pdf'):
                student_path = os.path.join(INPUT_DIR, filename)
                try:
                    result = self.grade_report(student_path, reference_content, reference_sections)
                    json_path = self.report_generator.generate_json_report(
                        result, filename, reference_filename, OUTPUT_DIR
                    )
                    html_path = self.report_generator.generate_html_report(
                        result, filename, reference_filename, OUTPUT_DIR
                    )
                    results.append({
                        'filename': filename,
                        'total_score': result['total_score'],
                        'json_report': json_path,
                        'html_report': html_path
                    })
                    print(f"已批改: {filename} -> 总分: {result['total_score']}")
                except Exception as e:
                    print(f"批改失败 {filename}: {str(e)}")
        
        return results

def main():
    print("=" * 60)
    print("      实训报告智能批改系统")
    print("=" * 60)
    
    reference_files = [f for f in os.listdir(REFERENCE_DIR) if f.endswith(('.docx', '.pdf'))]
    
    if not reference_files:
        print("错误：参考目录中未找到参考文档")
        print(f"请将参考文档放入: {REFERENCE_DIR}")
        return
    
    print("\n可用的参考文档：")
    for i, file in enumerate(reference_files, 1):
        print(f"{i}. {file}")
    
    choice = int(input("\n请选择参考文档序号: ")) - 1
    if choice < 0 or choice >= len(reference_files):
        print("无效选择")
        return
    
    reference_path = os.path.join(REFERENCE_DIR, reference_files[choice])
    
    student_files = [f for f in os.listdir(INPUT_DIR) if f.endswith(('.docx', '.pdf'))]
    if not student_files:
        print("错误：输入目录中未找到学生报告")
        print(f"请将学生报告放入: {INPUT_DIR}")
        return
    
    print(f"\n找到 {len(student_files)} 份学生报告待批改")
    
    system = ReportGradingSystem()
    
    try:
        results = system.batch_grade(reference_path)
        
        print("\n" + "=" * 60)
        print("              批改完成")
        print("=" * 60)
        print(f"参考文档: {reference_files[choice]}")
        print(f"批改报告数: {len(results)}")
        print("\n评分结果汇总:")
        for r in results:
            print(f"  {r['filename']}: {r['total_score']} 分")
        
        print(f"\n批改报告已保存至: {OUTPUT_DIR}")
        
    except Exception as e:
        print(f"批改进程出错: {str(e)}")

if __name__ == '__main__':
    main()
