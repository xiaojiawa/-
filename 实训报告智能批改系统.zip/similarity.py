import re
from difflib import SequenceMatcher

class SimilarityCalculator:
    def __init__(self):
        pass

    def clean_text(self, text):
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[^\w\s]', '', text)
        return text.strip()

    def simple_similarity(self, text1, text2):
        text1 = self.clean_text(text1)
        text2 = self.clean_text(text2)
        if not text1 or not text2:
            return 0.0
        return SequenceMatcher(None, text1, text2).ratio()

    def jaccard_similarity(self, text1, text2):
        text1 = self.clean_text(text1)
        text2 = self.clean_text(text2)
        if not text1 or not text2:
            return 0.0
        words1 = set(text1.split())
        words2 = set(text2.split())
        if not words1 and not words2:
            return 1.0
        intersection = words1 & words2
        union = words1 | words2
        return len(intersection) / len(union) if union else 0.0

    def combined_similarity(self, text1, text2):
        simple = self.simple_similarity(text1, text2)
        jaccard = self.jaccard_similarity(text1, text2)
        return (simple + jaccard) / 2

    def compare_sections(self, student_sections, reference_sections):
        results = {}
        for section_name, ref_section in reference_sections.items():
            stu_section = student_sections.get(section_name, {'found': False, 'content': ''})
            if ref_section['found']:
                if stu_section['found']:
                    similarity = self.combined_similarity(stu_section['content'], ref_section['content'])
                    results[section_name] = {
                        'found_in_student': True,
                        'found_in_reference': True,
                        'similarity': similarity,
                        'student_content': stu_section['content'],
                        'reference_content': ref_section['content']
                    }
                else:
                    results[section_name] = {
                        'found_in_student': False,
                        'found_in_reference': True,
                        'similarity': 0.0,
                        'student_content': '',
                        'reference_content': ref_section['content']
                    }
            else:
                results[section_name] = {
                    'found_in_student': stu_section['found'],
                    'found_in_reference': False,
                    'similarity': 1.0 if stu_section['found'] else 0.0,
                    'student_content': stu_section['content'],
                    'reference_content': ''
                }
        return results

    def extract_key_points(self, text, num_points=5):
        sentences = re.split(r'[。！？\n]', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        if not sentences:
            return []
        
        if len(sentences) <= num_points:
            return sentences
        
        scores = []
        for i, sentence in enumerate(sentences):
            score = len(sentence.split())
            if i > 0 and i < len(sentences) - 1:
                score += 2
            scores.append(score)
        
        top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:num_points]
        return [sentences[i] for i in top_indices]
